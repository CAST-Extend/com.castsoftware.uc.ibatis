application = None

def get_current_application():
    global application
    return application

def set_current_application(current):
    global application
    application = current
