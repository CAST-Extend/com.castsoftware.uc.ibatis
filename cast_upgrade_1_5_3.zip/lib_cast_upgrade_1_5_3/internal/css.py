'''
Created on 14 nov. 2016

@author: MRO
'''
import os
import subprocess



def backup(backup_file, host, port, user, schema):
    """
    Backup a schema into a file.
    """
    bin_path = get_bin_path()
    
    return_code = subprocess.call([bin_path +'/pg_dump.exe', 
                                   '--host', host,
                                   '--port', str(port),
                                   '--username', user,
                                   '--no-password', 
                                   '--schema', schema,
                                   '-Fc', '--compress=9',
                                   '--file', backup_file,
                                   'postgres'
                                   ])
    
    print(return_code)
    

def restore(backup_file, host, port, user):
    """
    Restore a backup.
    """
    bin_path = get_bin_path()
    
    return_code = subprocess.call([bin_path +'/pg_restore.exe', 
                                   '--host', host,
                                   '--port', str(port),
                                   '--username', user,
                                   '--dbname', "postgres",
                                   '--no-password', 
                                   '--clean',
                                   backup_file,
                                   ])
    print(return_code)


def get_bin_path():
    
    return os.path.join((os.path.dirname(__file__)), 'bin')
